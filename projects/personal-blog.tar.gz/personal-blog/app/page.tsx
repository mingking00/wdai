import Link from 'next/link'
import { format } from 'date-fns'
import { zhCN } from 'date-fns/locale'
import { getSortedPostsData } from '@/lib/posts'

export default async function Home() {
  const posts = getSortedPostsData()

  return (
    <div className="space-y-8">
      <section className="text-center py-12">
        <h1 className="text-4xl font-bold mb-4 gradient-text">
          欢迎来到我的博客
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          记录学习、分享技术、沉淀思考
        </p>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <span>最新文章</span>
          <span className="text-sm font-normal text-gray-500">({posts.length})</span>
        </h2>
        
        <div className="space-y-6">
          {posts.map((post) => (
            <article 
              key={post.id}
              className="border border-gray-200 dark:border-gray-800 rounded-lg p-6 hover:shadow-md transition-shadow"
            >
              <Link href={`/posts/${post.slug}/`} className="block">
                <h3 className="text-xl font-semibold mb-2 hover:text-primary-600 transition-colors">
                  {post.title}
                </h3>
              </Link>
              
              <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400 mb-3">
                <time>
                  {format(new Date(post.date), 'yyyy年MM月dd日', { locale: zhCN })}
                </time>
                <span>·</span>
                <span>{post.readingTime} 分钟阅读</span>
              </div>
              
              <p className="text-gray-600 dark:text-gray-400 line-clamp-2">
                {post.excerpt}
              </p>
              
              {post.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-4">
                  {post.tags.map((tag) => (
                    <Link
                      key={tag}
                      href={`/tags/${tag}/`}
                      className="text-xs px-3 py-1 bg-gray-100 dark:bg-gray-800 rounded-full hover:bg-primary-100 dark:hover:bg-primary-900 transition-colors"
                    >
                      {tag}
                    </Link>
                  ))}
                </div>
              )}
            </article>
          ))}
        </div>
      </section>
    </div>
  )
}
