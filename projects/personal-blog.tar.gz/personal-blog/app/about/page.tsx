export default function AboutPage() {
  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">关于我</h1>
      
      <div className="prose dark:prose-dark">
        <p>
          你好！我是一名开发者，这是我的个人博客。
        </p>
        
        <p>
          在这里，我会分享：
        </p>
        
        <ul>
          <li>技术学习笔记</li>
          <li>项目开发经验</li>
          <li>思考与感悟</li>
        </ul>

        <h2>技术栈</h2>
        
        <p>
          这个博客使用以下技术构建：
        </p>
        
        <ul>
          <li><strong>Next.js 14</strong> - React 框架</li>
          <li><strong>Tailwind CSS</strong> - 样式框架</li>
          <li><strong>Supabase</strong> - 后端服务</li>
          <li><strong>Vercel</strong> - 托管平台</li>
        </ul>

        <h2>联系方式</h2>
        
        <p>
          欢迎通过以下方式与我交流：
        </p>
        
        <ul>
          <li>GitHub: <a href="https://github.com" target="_blank" rel="noopener">@yourusername</a></li>
          <li>Email: your@email.com</li>
        </ul>
      </div>
    </div>
  )
}
