import { notFound } from 'next/navigation'
import { format } from 'date-fns'
import { zhCN } from 'date-fns/locale'
import { getPostData, getAllPostIds } from '@/lib/posts'
import ViewCounter from '@/components/ViewCounter'
import CommentSection from '@/components/CommentSection'
import 'highlight.js/styles/github-dark.css'

interface Props {
  params: Promise<{
    slug: string
  }>
}

export async function generateStaticParams() {
  const paths = getAllPostIds()
  return paths.map((path) => ({
    slug: path.params.slug,
  }))
}

export async function generateMetadata({ params }: Props) {
  const { slug } = await params
  const post = await getPostData(slug)
  
  if (!post) {
    return {
      title: 'Post Not Found',
    }
  }
  
  return {
    title: post.title,
    description: post.excerpt,
  }
}

export default async function PostPage({ params }: Props) {
  const { slug } = await params
  const post = await getPostData(slug)

  if (!post) {
    notFound()
  }

  return (
    <article className="max-w-3xl mx-auto">
      <header className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">
          {post.title}
        </h1>
        
        <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
          <time>
            {format(new Date(post.date), 'yyyy年MM月dd日', { locale: zhCN })}
          </time>
          <span>·</span>
          <span>{post.readingTime} 分钟阅读</span>
          <span>·</span>
          <ViewCounter slug={slug} />
        </div>
        
        {post.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-4">
            {post.tags.map((tag) => (
              <a
                key={tag}
                href={`/tags/${tag}/`}
                className="text-sm px-3 py-1 bg-gray-100 dark:bg-gray-800 rounded-full hover:bg-primary-100 dark:hover:bg-primary-900 transition-colors"
              >
                {tag}
              </a>
            ))}
          </div>
        )}
      </header>

      <div 
        className="prose prose-lg dark:prose-dark max-w-none"
        dangerouslySetInnerHTML={{ __html: post.content }}
      />

      <hr className="my-8 border-gray-200 dark:border-gray-800" />

      <CommentSection slug={slug} />
    </article>
  )
}
