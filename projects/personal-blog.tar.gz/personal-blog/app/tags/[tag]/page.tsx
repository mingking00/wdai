import { getSortedPostsData } from '@/lib/posts'
import Link from 'next/link'
import { format } from 'date-fns'
import { zhCN } from 'date-fns/locale'

interface Props {
  params: Promise<{
    tag: string
  }>
}

export async function generateStaticParams() {
  const posts = getSortedPostsData()
  const tags = new Set<string>()
  
  posts.forEach(post => {
    post.tags.forEach(tag => tags.add(tag))
  })
  
  return Array.from(tags).map(tag => ({
    tag: encodeURIComponent(tag),
  }))
}

export default async function TagPage({ params }: Props) {
  const { tag } = await params
  const decodedTag = decodeURIComponent(tag)
  const allPosts = getSortedPostsData()
  const posts = allPosts.filter(post => 
    post.tags.some(t => t.toLowerCase() === decodedTag.toLowerCase())
  )

  return (
    <div>
      <h1 className="text-3xl font-bold mb-2">标签: {decodedTag}</h1>
      <p className="text-gray-500 mb-8">共 {posts.length} 篇文章</p>

      <div className="space-y-6">
        {posts.map((post) => (
          <article 
            key={post.id}
            className="border border-gray-200 dark:border-gray-800 rounded-lg p-6"
          >
            <Link href={`/posts/${post.slug}/`}>
              <h2 className="text-xl font-semibold mb-2 hover:text-primary-600 transition-colors">
                {post.title}
              </h2>
            </Link>
            <div className="text-sm text-gray-500 mb-2">
              {format(new Date(post.date), 'yyyy年MM月dd日', { locale: zhCN })}
            </div>
            <p className="text-gray-600 dark:text-gray-400">{post.excerpt}</p>
          </article>
        ))}
      </div>

      {posts.length === 0 && (
        <p className="text-gray-500">该标签下暂无文章。</p>
      )}
    </div>
  )
}
