import Link from 'next/link'
import { getSortedPostsData } from '@/lib/posts'

export default async function TagsPage() {
  const posts = getSortedPostsData()
  
  // 收集所有标签
  const tagCount: Record<string, number> = {}
  posts.forEach(post => {
    post.tags.forEach(tag => {
      tagCount[tag] = (tagCount[tag] || 0) + 1
    })
  })
  
  const sortedTags = Object.entries(tagCount).sort((a, b) => b[1] - a[1])

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-center">标签云</h1>
      
      <div className="flex flex-wrap justify-center gap-3">
        {sortedTags.map(([tag, count]) => (
          <Link
            key={tag}
            href={`/tags/${encodeURIComponent(tag)}/`}
            className="px-4 py-2 bg-gray-100 dark:bg-gray-800 rounded-lg hover:bg-primary-100 dark:hover:bg-primary-900 transition-colors"
          >
            <span className="font-medium">{tag}</span>
            <span className="ml-2 text-sm text-gray-500">{count}</span>
          </Link>
        ))}
      </div>
      
      {sortedTags.length === 0 && (
        <p className="text-center text-gray-500 mt-8">暂无标签</p>
      )}
    </div>
  )
}
