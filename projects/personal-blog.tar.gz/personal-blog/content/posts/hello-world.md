---
title: "欢迎来到我的博客"
date: "2026-03-16"
excerpt: "这是我的第一篇博客文章，介绍这个博客的技术架构和功能特性。"
tags: ["nextjs", "blog", "supabase"]
---

## 欢迎来到我的博客！👋

这是我的个人博客，使用 **Next.js**、**Tailwind CSS** 和 **Supabase** 构建。

### 技术栈

| 技术 | 用途 |
|------|------|
| Next.js 14 | React 框架，支持静态生成 |
| Tailwind CSS | 原子化 CSS 框架 |
| Supabase | 后端服务（评论、统计） |
| Markdown | 文章写作 |

### 功能特性

- ✅ **静态生成** - 构建时生成所有页面，加载飞快
- ✅ **暗黑模式** - 支持亮色/暗色主题切换
- ✅ **评论系统** - 基于 Supabase 的评论功能
- ✅ **阅读统计** - 文章阅读量统计
- ✅ **标签系统** - 文章分类和标签
- ✅ **响应式设计** - 适配各种设备

### 代码示例

```typescript
// 获取文章列表
export async function getPosts() {
  const posts = await db.query('SELECT * FROM posts')
  return posts
}
```

### 开始使用

1. 克隆仓库
2. 安装依赖：`npm install`
3. 配置环境变量
4. 运行：`npm run dev`

---

感谢访问我的博客！🎉
