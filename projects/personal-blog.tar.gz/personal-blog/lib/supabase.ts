import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ''
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''

export const supabase = createClient(supabaseUrl, supabaseKey)

// 评论相关
export interface Comment {
  id: string
  post_slug: string
  author: string
  content: string
  created_at: string
}

export async function getComments(postSlug: string): Promise<Comment[]> {
  const { data, error } = await supabase
    .from('comments')
    .select('*')
    .eq('post_slug', postSlug)
    .order('created_at', { ascending: false })

  if (error) {
    console.error('Error fetching comments:', error)
    return []
  }

  return data || []
}

export async function addComment(
  postSlug: string,
  author: string,
  content: string
): Promise<boolean> {
  const { error } = await supabase.from('comments').insert([
    {
      post_slug: postSlug,
      author: author || 'Anonymous',
      content,
    },
  ])

  if (error) {
    console.error('Error adding comment:', error)
    return false
  }

  return true
}

// 访问量统计
export async function incrementView(postSlug: string): Promise<number> {
  // 先获取当前计数
  const { data: existing } = await supabase
    .from('page_views')
    .select('views')
    .eq('post_slug', postSlug)
    .single()

  if (existing) {
    const newViews = existing.views + 1
    await supabase
      .from('page_views')
      .update({ views: newViews, updated_at: new Date().toISOString() })
      .eq('post_slug', postSlug)
    return newViews
  } else {
    await supabase.from('page_views').insert([
      {
        post_slug: postSlug,
        views: 1,
      },
    ])
    return 1
  }
}

export async function getViews(postSlug: string): Promise<number> {
  const { data } = await supabase
    .from('page_views')
    .select('views')
    .eq('post_slug', postSlug)
    .single()

  return data?.views || 0
}
