-- Supabase 数据库初始化脚本
-- 在 Supabase SQL Editor 中执行

-- 1. 创建评论表
CREATE TABLE IF NOT EXISTS comments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    post_slug TEXT NOT NULL,
    author TEXT DEFAULT 'Anonymous',
    content TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. 创建页面访问统计表
CREATE TABLE IF NOT EXISTS page_views (
    post_slug TEXT PRIMARY KEY,
    views INTEGER DEFAULT 0,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. 创建索引（提高查询性能）
CREATE INDEX IF NOT EXISTS idx_comments_post_slug ON comments(post_slug);
CREATE INDEX IF NOT EXISTS idx_comments_created_at ON comments(created_at);

-- 4. 启用 RLS (Row Level Security) 但允许匿名访问
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE page_views ENABLE ROW LEVEL SECURITY;

-- 5. 创建允许匿名访问的策略
CREATE POLICY "Allow anonymous read comments" 
    ON comments FOR SELECT 
    TO anon 
    USING (true);

CREATE POLICY "Allow anonymous insert comments" 
    ON comments FOR INSERT 
    TO anon 
    WITH CHECK (true);

CREATE POLICY "Allow anonymous read views" 
    ON page_views FOR SELECT 
    TO anon 
    USING (true);

CREATE POLICY "Allow anonymous update views" 
    ON page_views FOR UPDATE 
    TO anon 
    USING (true);

CREATE POLICY "Allow anonymous insert views" 
    ON page_views FOR INSERT 
    TO anon 
    WITH CHECK (true);

-- 6. 验证表是否创建成功
SELECT 'comments table exists' as status WHERE EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_name = 'comments'
);

SELECT 'page_views table exists' as status WHERE EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_name = 'page_views'
);
