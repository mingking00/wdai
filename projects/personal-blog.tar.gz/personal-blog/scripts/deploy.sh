#!/bin/bash
#
# Personal Blog Deploy Script
# 一键部署个人博客到 Vercel + Supabase
#

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 项目配置
PROJECT_NAME=""
GITHUB_REPO=""
VERCEL_PROJECT=""
SUPABASE_PROJECT=""

# Token（运行时输入）
GITHUB_TOKEN=""
VERCEL_TOKEN=""
SUPABASE_ACCESS_TOKEN=""

# 打印带颜色的信息
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查依赖
check_dependencies() {
    print_info "检查依赖..."
    
    local deps=("curl" "jq" "git")
    for dep in "${deps[@]}"; do
        if ! command -v "$dep" &> /dev/null; then
            print_error "缺少依赖: $dep"
            echo "请安装:"
            echo "  Ubuntu/Debian: sudo apt-get install $dep"
            echo "  macOS: brew install $dep"
            exit 1
        fi
    done
    
    # 检查 Node.js
    if ! command -v node &> /dev/null; then
        print_error "缺少 Node.js"
        echo "请安装 Node.js 18+: https://nodejs.org"
        exit 1
    fi
    
    print_success "依赖检查通过"
}

# 显示欢迎信息
show_welcome() {
    clear
    echo "=========================================="
    echo "   🚀 Personal Blog 一键部署脚本"
    echo "=========================================="
    echo ""
    echo "这个脚本将帮你："
    echo "  1. 创建 GitHub 仓库"
    echo "  2. 创建 Supabase 项目"
    echo "  3. 部署到 Vercel"
    echo "  4. 配置自动构建"
    echo ""
    echo "💰 成本: ¥0/月 (使用免费额度)"
    echo ""
    read -p "按回车键继续..."
}

# 获取必要信息
get_user_input() {
    echo ""
    echo "=========================================="
    echo "   步骤 1/4: 项目配置"
    echo "=========================================="
    echo ""
    
    # 项目名称
    while true; do
        read -p "请输入项目名称 (如: my-blog): " PROJECT_NAME
        if [[ -n "$PROJECT_NAME" && "$PROJECT_NAME" =~ ^[a-z0-9-]+$ ]]; then
            break
        fi
        print_error "项目名称只能包含小写字母、数字和连字符"
    done
    
    # GitHub Token
    echo ""
    echo "👉 获取 GitHub Token:"
    echo "   1. 访问: https://github.com/settings/tokens"
    echo "   2. 点击 'Generate new token (classic)'"
    echo "   3. 勾选 'repo' 权限"
    echo "   4. 生成并复制 Token"
    echo ""
    read -s -p "请输入 GitHub Token: " GITHUB_TOKEN
    echo ""
    
    # Vercel Token
    echo ""
    echo "👉 获取 Vercel Token:"
    echo "   1. 访问: https://vercel.com/account/tokens"
    echo "   2. 点击 'Create Token'"
    echo "   3. 输入名称，选择 Scope"
    echo "   4. 复制 Token"
    echo ""
    read -s -p "请输入 Vercel Token: " VERCEL_TOKEN
    echo ""
    
    # Supabase Token
    echo ""
    echo "👉 获取 Supabase Access Token:"
    echo "   1. 访问: https://app.supabase.com/account/tokens"
    echo "   2. 点击 'Generate new token'"
    echo "   3. 复制 Token"
    echo ""
    read -s -p "请输入 Supabase Access Token: " SUPABASE_ACCESS_TOKEN
    echo ""
    
    # 组织/用户名
    echo ""
    read -p "请输入你的 GitHub 用户名: " GITHUB_USERNAME
    GITHUB_REPO="$GITHUB_USERNAME/$PROJECT_NAME"
}

# 验证 Token
verify_tokens() {
    print_info "验证 Token..."
    
    # 验证 GitHub Token
    local github_response=$(curl -s -H "Authorization: token $GITHUB_TOKEN" \
        https://api.github.com/user)
    
    if echo "$github_response" | grep -q "Bad credentials"; then
        print_error "GitHub Token 无效"
        exit 1
    fi
    
    local github_user=$(echo "$github_response" | jq -r '.login')
    print_success "GitHub Token 有效 (用户: $github_user)"
    
    # 验证 Vercel Token
    local vercel_response=$(curl -s -H "Authorization: Bearer $VERCEL_TOKEN" \
        https://api.vercel.com/v2/user)
    
    if echo "$vercel_response" | grep -q "FORBIDDEN"; then
        print_error "Vercel Token 无效"
        exit 1
    fi
    
    print_success "Vercel Token 有效"
    
    # 验证 Supabase Token
    local supabase_response=$(curl -s -H "Authorization: Bearer $SUPABASE_ACCESS_TOKEN" \
        https://api.supabase.io/v1/projects)
    
    if echo "$supabase_response" | grep -q "Unauthorized"; then
        print_error "Supabase Token 无效"
        exit 1
    fi
    
    print_success "Supabase Token 有效"
}

# 创建 GitHub 仓库
create_github_repo() {
    echo ""
    echo "=========================================="
    echo "   步骤 2/4: 创建 GitHub 仓库"
    echo "=========================================="
    echo ""
    
    print_info "创建 GitHub 仓库: $PROJECT_NAME"
    
    local response=$(curl -s -X POST \
        -H "Authorization: token $GITHUB_TOKEN" \
        -H "Accept: application/vnd.github.v3+json" \
        -d "{\"name\":\"$PROJECT_NAME\",\"private\":false,\"auto_init\":false}" \
        https://api.github.com/user/repos)
    
    if echo "$response" | grep -q "name already exists"; then
        print_warning "仓库已存在，将推送到现有仓库"
    elif echo "$response" | grep -q "\"id\":"; then
        print_success "GitHub 仓库创建成功"
        echo "   URL: https://github.com/$GITHUB_REPO"
    else
        print_error "创建 GitHub 仓库失败"
        echo "$response"
        exit 1
    fi
    
    # 配置 Git
    cd "$(dirname "$0")/.."
    
    if [ -d ".git" ]; then
        rm -rf .git
    fi
    
    git init
    git add .
    git commit -m "Initial commit"
    git branch -M main
    git remote add origin "https://$GITHUB_TOKEN@github.com/$GITHUB_REPO.git"
    
    print_info "推送代码到 GitHub..."
    git push -u origin main --force
    
    print_success "代码推送完成"
}

# 创建 Supabase 项目
create_supabase_project() {
    echo ""
    echo "=========================================="
    echo "   步骤 3/4: 创建 Supabase 项目"
    echo "=========================================="
    echo ""
    
    print_info "创建 Supabase 项目..."
    print_warning "注意: Supabase 项目创建需要约 2-3 分钟"
    
    # 获取组织 ID
    local orgs_response=$(curl -s -H "Authorization: Bearer $SUPABASE_ACCESS_TOKEN" \
        https://api.supabase.io/v1/organizations)
    
    local org_id=$(echo "$orgs_response" | jq -r '.[0].id')
    
    if [ -z "$org_id" ] || [ "$org_id" = "null" ]; then
        print_error "无法获取 Supabase 组织 ID"
        echo "请确保你已经创建了 Supabase 账户"
        exit 1
    fi
    
    # 创建项目
    local response=$(curl -s -X POST \
        -H "Authorization: Bearer $SUPABASE_ACCESS_TOKEN" \
        -H "Content-Type: application/json" \
        -d "{\"name\":\"$PROJECT_NAME\",\"org_id\":\"$org_id\",\"region\":\"ap-southeast-1\",\"plan\":\"free\"}" \
        https://api.supabase.io/v1/projects)
    
    if echo "$response" | grep -q "error"; then
        print_error "创建 Supabase 项目失败"
        echo "$response"
        exit 1
    fi
    
    SUPABASE_PROJECT=$(echo "$response" | jq -r '.ref')
    
    print_success "Supabase 项目创建成功: $SUPABASE_PROJECT"
    print_info "等待项目初始化 (约 2 分钟)..."
    
    # 等待项目就绪
    local attempts=0
    while [ $attempts -lt 30 ]; do
        sleep 5
        local status=$(curl -s -H "Authorization: Bearer $SUPABASE_ACCESS_TOKEN" \
            "https://api.supabase.io/v1/projects/$SUPABASE_PROJECT" | jq -r '.status')
        
        if [ "$status" = "ACTIVE" ]; then
            break
        fi
        
        attempts=$((attempts + 1))
        echo -n "."
    done
    echo ""
    
    # 获取项目信息
    local project_info=$(curl -s -H "Authorization: Bearer $SUPABASE_ACCESS_TOKEN" \
        "https://api.supabase.io/v1/projects/$SUPABASE_PROJECT")
    
    local supabase_url="https://$SUPABASE_PROJECT.supabase.co"
    local anon_key=$(echo "$project_info" | jq -r '.anon_key')
    
    print_success "Supabase 项目就绪"
    echo "   URL: $supabase_url"
    
    # 保存配置
    echo "SUPABASE_PROJECT=$SUPABASE_PROJECT" > .deploy.env
    echo "SUPABASE_URL=$supabase_url" >> .deploy.env
    echo "SUPABASE_ANON_KEY=$anon_key" >> .deploy.env
    
    # 初始化数据库
    print_info "初始化数据库..."
    
    # 获取 Service Role Key
    local service_key=$(curl -s -H "Authorization: Bearer $SUPABASE_ACCESS_TOKEN" \
        "https://api.supabase.io/v1/projects/$SUPABASE_PROJECT/api-keys" | jq -r '.[] | select(.name=="service_role") | .api_key')
    
    if [ -n "$service_key" ] && [ -f "supabase/init.sql" ]; then
        # 执行 SQL
        curl -s -X POST \
            -H "Authorization: Bearer $service_key" \
            -H "Content-Type: application/json" \
            -d "{\"query\":$(jq -Rs . < supabase/init.sql)}" \
            "$supabase_url/rest/v1/" > /dev/null 2>&1 || true
        
        print_success "数据库初始化完成"
    fi
    
    # 导出环境变量
    export NEXT_PUBLIC_SUPABASE_URL="$supabase_url"
    export NEXT_PUBLIC_SUPABASE_ANON_KEY="$anon_key"
}

# 部署到 Vercel
deploy_to_vercel() {
    echo ""
    echo "=========================================="
    echo "   步骤 4/4: 部署到 Vercel"
    echo "=========================================="
    echo ""
    
    print_info "创建 Vercel 项目..."
    
    # 创建项目
    local response=$(curl -s -X POST \
        -H "Authorization: Bearer $VERCEL_TOKEN" \
        -H "Content-Type: application/json" \
        -d "{\"name\":\"$PROJECT_NAME\",\"framework\":\"nextjs\"}" \
        https://api.vercel.com/v9/projects)
    
    if echo "$response" | grep -q "\"id\":"; then
        VERCEL_PROJECT=$(echo "$response" | jq -r '.id')
        print_success "Vercel 项目创建成功"
    elif echo "$response" | grep -q "already exists"; then
        print_warning "项目已存在，使用现有项目"
        VERCEL_PROJECT=$(curl -s -H "Authorization: Bearer $VERCEL_TOKEN" \
            "https://api.vercel.com/v9/projects/$PROJECT_NAME" | jq -r '.id')
    else
        print_error "创建 Vercel 项目失败"
        echo "$response"
        exit 1
    fi
    
    # 配置环境变量
    print_info "配置环境变量..."
    
    local env_vars='['
    env_vars+='{"key":"NEXT_PUBLIC_SUPABASE_URL","value":"'"$NEXT_PUBLIC_SUPABASE_URL"'","target":["production","preview","development"]},'
    env_vars+='{"key":"NEXT_PUBLIC_SUPABASE_ANON_KEY","value":"'"$NEXT_PUBLIC_SUPABASE_ANON_KEY"'","target":["production","preview","development"]}'
    env_vars+=']'
    
    curl -s -X POST \
        -H "Authorization: Bearer $VERCEL_TOKEN" \
        -H "Content-Type: application/json" \
        -d "$env_vars" \
        "https://api.vercel.com/v9/projects/$VERCEL_PROJECT/env" > /dev/null
    
    print_success "环境变量配置完成"
    
    # 连接 GitHub 仓库
    print_info "连接 GitHub 仓库..."
    
    curl -s -X POST \
        -H "Authorization: Bearer $VERCEL_TOKEN" \
        -H "Content-Type: application/json" \
        -d "{\"type\":\"github\",\"repo\":\"$GITHUB_REPO\",\"branch\":\"main\"}" \
        "https://api.vercel.com/v9/projects/$VERCEL_PROJECT/link" > /dev/null
    
    print_success "GitHub 仓库连接完成"
    
    # 触发部署
    print_info "触发部署..."
    
    local deploy_response=$(curl -s -X POST \
        -H "Authorization: Bearer $VERCEL_TOKEN" \
        -H "Content-Type: application/json" \
        -d "{\"name\":\"$PROJECT_NAME\",\"project\":\"$VERCEL_PROJECT\",\"target\":\"production\"}" \
        https://api.vercel.com/v13/deployments)
    
    local deploy_url=$(echo "$deploy_response" | jq -r '.url')
    local deploy_id=$(echo "$deploy_response" | jq -r '.id')
    
    if [ -n "$deploy_url" ] && [ "$deploy_url" != "null" ]; then
        print_success "部署已触发"
        echo "   部署 ID: $deploy_id"
        
        # 等待部署完成
        print_info "等待部署完成 (约 1-2 分钟)..."
        
        local attempts=0
        while [ $attempts -lt 30 ]; do
            sleep 5
            local status=$(curl -s -H "Authorization: Bearer $VERCEL_TOKEN" \
                "https://api.vercel.com/v13/deployments/$deploy_id" | jq -r '.readyState')
            
            if [ "$status" = "READY" ]; then
                break
            elif [ "$status" = "ERROR" ]; then
                print_error "部署失败"
                exit 1
            fi
            
            attempts=$((attempts + 1))
            echo -n "."
        done
        echo ""
        
        print_success "部署完成！"
        echo ""
        echo "=========================================="
        echo "   🎉 部署成功！"
        echo "=========================================="
        echo ""
        echo "🔗 访问你的博客:"
        echo "   https://$deploy_url"
        echo ""
        echo "📁 项目管理:"
        echo "   GitHub: https://github.com/$GITHUB_REPO"
        echo "   Vercel: https://vercel.com/dashboard"
        echo "   Supabase: https://app.supabase.com/project/$SUPABASE_PROJECT"
        echo ""
    else
        print_error "部署触发失败"
        echo "$deploy_response"
        exit 1
    fi
}

# 清理敏感信息
cleanup() {
    print_info "清理临时文件..."
    if [ -f .deploy.env ]; then
        rm .deploy.env
    fi
    # 重置 Git remote
    git remote set-url origin "https://github.com/$GITHUB_REPO.git" 2>/dev/null || true
}

# 主函数
main() {
    trap cleanup EXIT
    
    show_welcome
    check_dependencies
    get_user_input
    verify_tokens
    create_github_repo
    create_supabase_project
    deploy_to_vercel
    
    echo ""
    echo "💡 提示:"
    echo "   - 在 content/posts/ 目录添加 Markdown 文章"
    echo "   - 推送到 GitHub 会自动重新部署"
    echo "   - 第一次访问可能需要等待 CDN 生效 (1-2 分钟)"
    echo ""
    echo "📝 写作指南:"
    echo "   1. 在 content/posts/ 创建 .md 文件"
    echo "   2. 添加 Frontmatter (title, date, excerpt, tags)"
    echo "   3. git add . && git commit -m 'new post' && git push"
    echo ""
}

# 运行
main
