#!/bin/bash
#
# 交互式部署脚本 (Interactive Deploy)
# 不需要提前准备 Token，跟随提示操作即可
#

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo ""
echo "=========================================="
echo "   🚀 Personal Blog 交互式部署"
echo "=========================================="
echo ""
echo "这个脚本将引导你完成部署，无需提前准备 Token。"
echo ""

# 检查 Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}错误: 需要 Node.js 18+${NC}"
    echo "请安装: https://nodejs.org"
    exit 1
fi

# 进入项目目录
cd "$(dirname "$0")/.."

# 步骤 1: 安装依赖
echo ""
echo "步骤 1/4: 安装依赖..."
npm install

# 步骤 2: 安装 Vercel CLI
echo ""
echo "步骤 2/4: 安装 Vercel CLI..."
npm install -g vercel

# 步骤 3: 部署到 Vercel
echo ""
echo "=========================================="
echo "   步骤 3/4: 部署到 Vercel"
echo "=========================================="
echo ""
echo "接下来会打开浏览器让你登录 Vercel。"
echo "如果已经登录过，会直接继续。"
echo ""
read -p "按回车键继续..."

# 使用 vercel CLI 交互式部署
echo ""
echo -e "${BLUE}正在部署...${NC}"
echo ""

# 先尝试部署，获取预览 URL
vercel --yes

echo ""
echo -e "${GREEN}✅ Vercel 部署完成！${NC}"

# 步骤 4: 配置 Supabase
echo ""
echo "=========================================="
echo "   步骤 4/4: 配置 Supabase"
echo "=========================================="
echo ""
echo "现在需要配置 Supabase 数据库:"
echo ""
echo "1. 访问: https://supabase.com"
echo "2. 点击 'New Project'"
echo "3. 创建项目（选择 Free 计划）"
echo "4. 等待项目创建完成"
echo "5. 进入 SQL Editor"
echo "6. 新建 Query，粘贴以下内容:"
echo ""
echo "--- SQL 开始 ---"
cat supabase/init.sql
echo "--- SQL 结束 ---"
echo ""
echo "7. 点击 'Run' 执行"
echo "8. 进入 Settings → API"
echo "9. 复制 'Project URL' 和 'anon public' key"
echo ""
read -p "按回车键继续配置环境变量..."

# 获取环境变量
echo ""
echo "请输入 Supabase 配置:"
read -p "Project URL (如: https://xxx.supabase.co): " SUPABASE_URL
read -p "Anon Key: " SUPABASE_KEY

# 添加到 Vercel 环境变量
echo ""
echo "正在配置环境变量..."
vercel env add NEXT_PUBLIC_SUPABASE_URL production <<EOF
$SUPABASE_URL
EOF

vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY production <<EOF
$SUPABASE_KEY
EOF

# 重新部署以应用环境变量
echo ""
echo "重新部署以应用环境变量..."
vercel --prod

echo ""
echo "=========================================="
echo "   🎉 部署完成！"
echo "=========================================="
echo ""
echo -e "${GREEN}你的博客已上线！${NC}"
echo ""
echo "📝 写作方法:"
echo "   1. 在 content/posts/ 目录创建 .md 文件"
echo "   2. 添加 frontmatter (title, date, excerpt, tags)"
echo "   3. 运行: vercel --prod"
echo ""
echo "💡 常用命令:"
echo "   npm run dev      # 本地开发"
echo "   vercel           # 预览部署"
echo "   vercel --prod    # 生产部署"
echo ""
