# Personal Blog Deploy Script for Windows (PowerShell)
# 一键部署个人博客到 Vercel + Supabase

$ErrorActionPreference = "Stop"

function Write-Info($msg) { Write-Host "[INFO] $msg" -ForegroundColor Blue }
function Write-Success($msg) { Write-Host "[OK] $msg" -ForegroundColor Green }
function Write-Error($msg) { Write-Host "[ERROR] $msg" -ForegroundColor Red }
function Write-Warning($msg) { Write-Host "[WARNING] $msg" -ForegroundColor Yellow }

# 显示欢迎信息
Clear-Host
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "   🚀 Personal Blog 部署脚本 (PowerShell)" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "这个脚本将引导你完成部署。" -ForegroundColor White
Write-Host ""
Read-Host "按回车键继续"

# 检查 Node.js
Write-Host ""
Write-Info "检查 Node.js..."
try {
    $nodeVersion = node --version 2>$null
    if ($LASTEXITCODE -ne 0) { throw }
    Write-Success "Node.js 已安装: $nodeVersion"
} catch {
    Write-Error "需要 Node.js 18+"
    Write-Host "请安装: https://nodejs.org"
    Read-Host "按回车键退出"
    exit 1
}

# 进入项目目录
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectPath = Join-Path $scriptPath ".."
Set-Location $projectPath

# 步骤 1: 安装依赖
Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "   步骤 1/4: 安装依赖" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

try {
    npm install
    if ($LASTEXITCODE -ne 0) { throw }
    Write-Success "依赖安装完成"
} catch {
    Write-Error "依赖安装失败"
    Read-Host "按回车键退出"
    exit 1
}

# 步骤 2: 安装 Vercel CLI
Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "   步骤 2/4: 安装 Vercel CLI" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

try {
    npm install -g vercel
    Write-Success "Vercel CLI 准备完成"
} catch {
    Write-Warning "Vercel CLI 安装失败，可能已安装"
}

# 步骤 3: 部署到 Vercel
Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "   步骤 3/4: 部署到 Vercel" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "接下来会打开浏览器让你登录 Vercel。" -ForegroundColor White
Write-Host "如果已经登录过，会直接继续。" -ForegroundColor White
Write-Host ""
Read-Host "按回车键继续"

Write-Host ""
Write-Info "正在部署..."
Write-Host ""

try {
    vercel --yes
    if ($LASTEXITCODE -ne 0) { throw }
    Write-Host ""
    Write-Success "Vercel 部署完成！"
} catch {
    Write-Error "Vercel 部署失败"
    Read-Host "按回车键退出"
    exit 1
}

# 步骤 4: 配置 Supabase
Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "   步骤 4/4: 配置 Supabase" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "现在需要配置 Supabase 数据库:" -ForegroundColor White
Write-Host ""
Write-Host "1. 访问: https://supabase.com" -ForegroundColor Yellow
Write-Host "2. 点击 'New Project'" -ForegroundColor Yellow
Write-Host "3. 创建项目（选择 Free 计划）" -ForegroundColor Yellow
Write-Host "4. 等待项目创建完成" -ForegroundColor Yellow
Write-Host "5. 进入 SQL Editor" -ForegroundColor Yellow
Write-Host "6. 新建 Query，粘贴以下内容:" -ForegroundColor Yellow
Write-Host ""
Write-Host "--- SQL 开始 ---" -ForegroundColor Gray
Get-Content "supabase\init.sql" | Write-Host -ForegroundColor Gray
Write-Host "--- SQL 结束 ---" -ForegroundColor Gray
Write-Host ""
Write-Host "7. 点击 'Run' 执行" -ForegroundColor Yellow
Write-Host "8. 进入 Settings → API" -ForegroundColor Yellow
Write-Host "9. 复制 'Project URL' 和 'anon public' key" -ForegroundColor Yellow
Write-Host ""
Read-Host "按回车键继续配置环境变量"

# 获取环境变量
Write-Host ""
Write-Host "请输入 Supabase 配置:" -ForegroundColor White
$SUPABASE_URL = Read-Host "Project URL (如: https://xxx.supabase.co)"
$SUPABASE_KEY = Read-Host "Anon Key"

# 添加到 Vercel 环境变量
Write-Host ""
Write-Info "正在配置环境变量..."
$SUPABASE_URL | vercel env add NEXT_PUBLIC_SUPABASE_URL production
$SUPABASE_KEY | vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY production

# 重新部署
Write-Host ""
Write-Info "重新部署以应用环境变量..."
try {
    vercel --prod
    if ($LASTEXITCODE -ne 0) { throw }
} catch {
    Write-Error "生产部署失败"
    Read-Host "按回车键退出"
    exit 1
}

# 完成
Write-Host ""
Write-Host "==========================================" -ForegroundColor Green
Write-Host "   🎉 部署完成！" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Green
Write-Host ""
Write-Success "你的博客已上线！"
Write-Host ""
Write-Host "📝 写作方法:" -ForegroundColor Cyan
Write-Host "   1. 在 content/posts/ 目录创建 .md 文件" -ForegroundColor White
Write-Host "   2. 添加 frontmatter (title, date, excerpt, tags)" -ForegroundColor White
Write-Host "   3. 运行: vercel --prod" -ForegroundColor White
Write-Host ""
Write-Host "💡 常用命令:" -ForegroundColor Cyan
Write-Host "   npm run dev      本地开发" -ForegroundColor White
Write-Host "   vercel           预览部署" -ForegroundColor White
Write-Host "   vercel --prod    生产部署" -ForegroundColor White
Write-Host ""
Read-Host "按回车键退出"
