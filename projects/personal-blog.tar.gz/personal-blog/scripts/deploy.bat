@echo off
setlocal enabledelayedexpansion

:: Personal Blog Deploy Script for Windows
chcp 65001 > nul

echo ==========================================
echo    🚀 Personal Blog 部署脚本 (Windows)
echo ==========================================
echo.
echo 这个脚本将引导你完成部署
echo.
pause

:: 检查 Node.js
echo.
echo 检查 Node.js...
node -v > nul 2>&1
if errorlevel 1 (
    echo [错误] 需要 Node.js 18+
    echo 请安装: https://nodejs.org
    pause
    exit /b 1
)
echo [OK] Node.js 已安装

:: 进入项目目录
cd /d "%~dp0\.."

:: 步骤 1: 安装依赖
echo.
echo ==========================================
echo    步骤 1/4: 安装依赖
echo ==========================================
echo.
call npm install
if errorlevel 1 (
    echo [错误] 依赖安装失败
    pause
    exit /b 1
)
echo [OK] 依赖安装完成

:: 步骤 2: 安装 Vercel CLI
echo.
echo ==========================================
echo    步骤 2/4: 安装 Vercel CLI
echo ==========================================
echo.
call npm install -g vercel
echo [OK] Vercel CLI 准备完成

:: 步骤 3: 部署到 Vercel
echo.
echo ==========================================
echo    步骤 3/4: 部署到 Vercel
echo ==========================================
echo.
echo 接下来会打开浏览器让你登录 Vercel
echo 如果已经登录过，会直接继续
echo.
pause

echo.
echo [INFO] 正在部署...
echo.
call vercel --yes
if errorlevel 1 (
    echo [错误] Vercel 部署失败
    pause
    exit /b 1
)
echo [OK] Vercel 部署完成

:: 步骤 4: 配置 Supabase
echo.
echo ==========================================
echo    步骤 4/4: 配置 Supabase
echo ==========================================
echo.
echo 现在需要配置 Supabase 数据库:
echo.
echo 1. 访问: https://supabase.com
echo 2. 点击 'New Project'
echo 3. 创建项目 (选择 Free 计划)
echo 4. 等待项目创建完成
echo 5. 进入 SQL Editor
echo 6. 新建 Query, 粘贴以下内容:
echo.
echo --- SQL 开始 ---
type supabase\init.sql
echo --- SQL 结束 ---
echo.
echo 7. 点击 'Run' 执行
echo 8. 进入 Settings -^> API
echo 9. 复制 'Project URL' 和 'anon public' key
echo.
pause

:: 获取环境变量
echo.
echo 请输入 Supabase 配置:
set /p SUPABASE_URL="Project URL: "
set /p SUPABASE_KEY="Anon Key: "

:: 添加到 Vercel 环境变量
echo.
echo [INFO] 正在配置环境变量...
echo %SUPABASE_URL% | vercel env add NEXT_PUBLIC_SUPABASE_URL production
echo %SUPABASE_KEY% | vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY production

:: 重新部署
echo.
echo [INFO] 重新部署以应用环境变量...
call vercel --prod
if errorlevel 1 (
    echo [错误] 生产部署失败
    pause
    exit /b 1
)

:: 完成
echo.
echo ==========================================
echo    🎉 部署完成！
echo ==========================================
echo.
echo 你的博客已上线！
echo.
echo 📝 写作方法:
echo    1. 在 content/posts/ 目录创建 .md 文件
echo    2. 添加 frontmatter (title, date, excerpt, tags)
echo    3. 运行: vercel --prod
echo.
pause
