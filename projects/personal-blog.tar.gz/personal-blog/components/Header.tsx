'use client'

import Link from 'next/link'
import ThemeToggle from './ThemeToggle'

export default function Header() {
  return (
    <header className="border-b border-gray-200 dark:border-gray-800">
      <div className="container mx-auto px-4 py-4 max-w-4xl flex justify-between items-center">
        <Link href="/" className="text-xl font-bold gradient-text">
          My Blog
        </Link>
        <nav className="flex items-center gap-6">
          <Link 
            href="/" 
            className="text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
          >
            首页
          </Link>
          <Link 
            href="/tags" 
            className="text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
          >
            标签
          </Link>
          <Link 
            href="/about" 
            className="text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
          >
            关于
          </Link>
          <ThemeToggle />
        </nav>
      </div>
    </header>
  )
}
