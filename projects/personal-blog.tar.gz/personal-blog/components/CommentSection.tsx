'use client'

import { useState, useEffect } from 'react'
import { getComments, addComment } from '@/lib/supabase'

interface Comment {
  id: string
  post_slug: string
  author: string
  content: string
  created_at: string
}

interface CommentSectionProps {
  slug: string
}

export default function CommentSection({ slug }: CommentSectionProps) {
  const [comments, setComments] = useState<Comment[]>([])
  const [author, setAuthor] = useState('')
  const [content, setContent] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadComments()
  }, [slug])

  const loadComments = async () => {
    try {
      const data = await getComments(slug)
      setComments(data)
    } catch (error) {
      console.error('Error loading comments:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!content.trim()) return
    
    setIsSubmitting(true)
    
    try {
      const success = await addComment(slug, author, content)
      if (success) {
        setAuthor('')
        setContent('')
        await loadComments()
      }
    } catch (error) {
      console.error('Error submitting comment:', error)
      alert('提交失败，请重试')
    } finally {
      setIsSubmitting(false)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  return (
    <section className="mt-12">
      <h3 className="text-2xl font-bold mb-6">评论 ({comments.length})</h3>

      {/* 评论表单 */}
      <form onSubmit={handleSubmit} className="mb-8 space-y-4">
        <div>
          <label htmlFor="author" className="block text-sm font-medium mb-1">
            昵称（可选）
          </label>
          <input
            type="text"
            id="author"
            value={author}
            onChange={(e) => setAuthor(e.target.value)}
            placeholder="匿名"
            className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          />
        </div>
        
        <div>
          <label htmlFor="content" className="block text-sm font-medium mb-1">
            评论内容 *
          </label>
          <textarea
            id="content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="写下你的想法..."
            rows={4}
            required
            className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-primary-500 focus:border-transparent resize-none"
          />
        </div>
        
        <button
          type="submit"
          disabled={isSubmitting || !content.trim()}
          className="px-6 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {isSubmitting ? '提交中...' : '发表评论'}
        </button>
      </form>

      {/* 评论列表 */}
      <div className="space-y-6">
        {isLoading ? (
          <p className="text-gray-500">加载评论中...⏳</p>
        ) : comments.length === 0 ? (
          <p className="text-gray-500">暂无评论，来发表第一条评论吧！✍️</p>
        ) : (
          comments.map((comment) => (
            <div 
              key={comment.id}
              className="border-b border-gray-200 dark:border-gray-800 pb-6 last:border-0"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium">
                  {comment.author || '匿名用户'}
                </span>
                <time className="text-sm text-gray-500">
                  {formatDate(comment.created_at)}
                </time>
              </div>
              <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                {comment.content}
              </p>
            </div>
          ))
        )}
      </div>
    </section>
  )
}
