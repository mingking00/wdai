/**
 * 翻译器模块
 * 支持多种翻译方式：本地简单翻译、Demo模式、AI API翻译
 */

class Translator {
    constructor() {
        this.model = localStorage.getItem('translation-model') || 'demo';
        this.cache = new Map();
        this.loadCache();
    }

    // 设置翻译模型
    setModel(model) {
        this.model = model;
        localStorage.setItem('translation-model', model);
    }

    // 翻译文本
    async translate(text, from = 'zh', to = 'en') {
        // 检查缓存
        const cacheKey = `${from}:${to}:${text}`;
        if (this.cache.has(cacheKey)) {
            return this.cache.get(cacheKey);
        }

        let result;
        switch (this.model) {
            case 'local':
                result = await this.localTranslate(text, from, to);
                break;
            case 'demo':
                result = await this.demoTranslate(text, from, to);
                break;
            case 'ai':
                result = await this.aiTranslate(text, from, to);
                break;
            default:
                result = await this.demoTranslate(text, from, to);
        }

        // 存入缓存
        this.cache.set(cacheKey, result);
        this.saveCache();
        return result;
    }

    // Demo模式翻译（模拟AI翻译）
    async demoTranslate(text, from = 'zh', to = 'en') {
        // 模拟网络延迟
        await this.delay(500 + Math.random() * 1000);

        // 简单的模拟翻译规则
        const translations = {
            '克劳德': 'Cloud',
            '蒂法': 'Tifa',
            '爱丽丝': 'Aerith',
            '巴雷特': 'Barret',
            '萨菲罗斯': 'Sephiroth',
            '扎克斯': 'Zack',
            '魔晄': 'Mako',
            '魔石': 'Materia',
            '神罗公司': 'Shinra Electric Power Company',
            '雪崩': 'AVALANCHE',
            '生命之流': 'Lifestream',
            '古代种': 'The Ancients',
            '杰诺瓦': 'Jenova',
            '米德加': 'Midgar',
            '星球': 'the Planet',
        };

        let translated = text;

        // 替换已知术语
        for (const [cn, en] of Object.entries(translations)) {
            translated = translated.replace(new RegExp(cn, 'g'), en);
        }

        // 如果不是完全替换，添加模拟翻译标记
        if (translated === text && text.length > 10) {
            // 生成模拟的英文段落
            translated = this.generateMockTranslation(text);
        } else if (translated === text) {
            translated = `[EN] ${text}`;
        }

        return translated;
    }

    // 生成长文本的模拟翻译
    generateMockTranslation(chineseText) {
        // 基于文本长度生成看起来合理的英文段落
        const sentences = chineseText.split(/[。！？；]/).filter(s => s.trim());
        
        return sentences.map((sentence, index) => {
            const length = sentence.length;
            // 生成与原文大致等长的模拟英文
            const mockWords = this.generateMockWords(Math.max(5, length / 2));
            return mockWords + '.';
        }).join(' ');
    }

    // 生成模拟英文单词
    generateMockWords(count) {
        const words = [
            'The', 'a', 'in', 'on', 'with', 'through', 'towards', 'from', 'Cloud', 'Tifa', 
            'Aerith', 'Barret', 'Sephiroth', 'Mako', 'Materia', 'Shinra', 'AVALANCHE',
            'Lifestream', 'ancient', 'Jenova', 'Midgar', 'Sector', 'slums', 'reactor',
            'energy', 'planet', 'world', 'city', 'building', 'street', 'room',
            'looked', 'felt', 'thought', 'said', 'went', 'came', 'stood', 'walked',
            'cold', 'warm', 'dark', 'bright', 'large', 'small', 'old', 'new',
            'sword', 'gun', 'flower', 'bar', 'church', 'tower', 'bridge'
        ];
        
        const result = [];
        for (let i = 0; i < count; i++) {
            result.push(words[Math.floor(Math.random() * words.length)]);
        }
        
        // 首字母大写
        let text = result.join(' ').toLowerCase();
        text = text.charAt(0).toUpperCase() + text.slice(1);
        return text;
    }

    // 本地简单翻译（使用本地词典）
    async localTranslate(text, from = 'zh', to = 'en') {
        await this.delay(100);
        
        // 简单的词汇替换
        const dictionary = {
            '他': 'he', '她': 'she', '它': 'it',
            '的': '', '了': '', '在': 'at', '是': 'is',
            '和': 'and', '与': 'and', '或': 'or',
            '我': 'I', '你': 'you', '我们': 'we',
            '这': 'this', '那': 'that', '什么': 'what',
            '怎么': 'how', '为什么': 'why', '哪里': 'where',
            '好': 'good', '大': 'big', '小': 'small',
            '来': 'come', '去': 'go', '走': 'walk',
            '看': 'see', '听': 'hear', '说': 'say',
            '想': 'think', '知道': 'know', '喜欢': 'like'
        };

        let result = text;
        for (const [cn, en] of Object.entries(dictionary)) {
            result = result.replace(new RegExp(cn, 'g'), en);
        }
        
        return result;
    }

    // AI翻译（可接入真实API）
    async aiTranslate(text, from = 'zh', to = 'en') {
        // 这里可以接入真实的AI翻译API
        // 如：OpenAI、Claude、Google Translate、DeepL等
        
        // 示例：调用本地或远程API
        try {
            // const response = await fetch('/api/translate', {
            //     method: 'POST',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify({ text, from, to })
            // });
            // const data = await response.json();
            // return data.translation;

            // 目前回退到demo模式
            return await this.demoTranslate(text, from, to);
        } catch (error) {
            console.error('AI翻译失败:', error);
            return await this.demoTranslate(text, from, to);
        }
    }

    // 翻译整章（分段处理）
    async translateChapter(content) {
        // 提取段落
        const paragraphs = this.extractParagraphs(content);
        
        // 显示进度
        updateLoading(true, `翻译中... 0/${paragraphs.length}`);
        
        const translatedParagraphs = [];
        for (let i = 0; i < paragraphs.length; i++) {
            const para = paragraphs[i];
            if (para.trim()) {
                const translated = await this.translate(para);
                translatedParagraphs.push({
                    original: para,
                    translated: translated,
                    id: `para-${i}`
                });
                
                // 更新进度
                updateLoading(true, `翻译中... ${i + 1}/${paragraphs.length}`);
            }
        }
        
        updateLoading(false);
        return translatedParagraphs;
    }

    // 从HTML内容提取段落
    extractParagraphs(htmlContent) {
        // 临时创建元素解析HTML
        const temp = document.createElement('div');
        temp.innerHTML = htmlContent;
        
        // 获取所有段落和文本节点
        const paragraphs = [];
        const textElements = temp.querySelectorAll('p, div, h1, h2, h3, h4, h5, h6');
        
        textElements.forEach(el => {
            const text = el.textContent.trim();
            if (text && text.length > 5) {
                paragraphs.push(text);
            }
        });
        
        // 如果没有找到段落，尝试按句子分割
        if (paragraphs.length === 0) {
            const text = temp.textContent || htmlContent;
            return text.split(/[。！？]/).filter(s => s.trim().length > 5);
        }
        
        return paragraphs;
    }

    // 渲染翻译结果
    renderTranslation(translatedParagraphs) {
        const container = document.getElementById('english-content');
        
        container.innerHTML = translatedParagraphs.map(para => `
            <div class="translation-paragraph" data-para-id="${para.id}"
                 onmouseenter="syncScroll('${para.id}')"
                 onmouseleave="clearSync()">
                ${this.escapeHtml(para.translated)}
            </div>
        `).join('');
    }

    // HTML转义
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // 延迟函数
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // 保存缓存到localStorage
    saveCache() {
        const cacheObj = Object.fromEntries(this.cache);
        localStorage.setItem('translation-cache', JSON.stringify(cacheObj));
    }

    // 从localStorage加载缓存
    loadCache() {
        try {
            const saved = localStorage.getItem('translation-cache');
            if (saved) {
                const cacheObj = JSON.parse(saved);
                this.cache = new Map(Object.entries(cacheObj));
            }
        } catch (e) {
            console.error('加载缓存失败:', e);
        }
    }

    // 清空缓存
    clearCache() {
        this.cache.clear();
        localStorage.removeItem('translation-cache');
    }
}

// 全局同步滚动状态
let currentSyncPara = null;

// 同步滚动
function syncScroll(paraId) {
    currentSyncPara = paraId;
}

function clearSync() {
    currentSyncPara = null;
}

// 初始化翻译器
const translator = new Translator();

// 更新加载提示
function updateLoading(show, text = '加载中...') {
    const loading = document.getElementById('loading');
    const loadingText = document.getElementById('loading-text');
    
    if (show) {
        loading.classList.remove('hidden');
        loadingText.textContent = text;
    } else {
        loading.classList.add('hidden');
    }
}