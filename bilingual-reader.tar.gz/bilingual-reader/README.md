# AI双语阅读器 (AI Bilingual Reader)

基于 **epub.js** 构建的浏览器端双语小说阅读器，支持AI翻译、术语高亮和智能解释。

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-MIT-green)

## ✨ 核心功能

### 📖 阅读功能
- **EPUB解析**：完整的EPUB电子书解析和渲染
- **目录导航**：章节跳转、目录树展示
- **阅读设置**：字体大小、行高、主题（浅色/深色/sepia）
- **响应式设计**：适配桌面和移动设备

### 🌐 双语对照
- **AI翻译**：整章翻译，逐段对照
- **双语模式**：左右分栏显示中英文
- **翻译缓存**：本地存储翻译结果，避免重复请求

### 📚 术语系统
- **智能高亮**：自动识别并高亮文中术语
- **点击解释**：点击术语查看详细解释
- **术语分类**：人物、概念、地点分类管理
- **可扩展**：支持自定义术语表

### 🤖 AI功能
- **多模型支持**：Demo模式、本地简单翻译、AI API（可扩展）
- **段落级翻译**：保持段落结构对照
- **术语识别**：翻译时保留专有名词

## 🚀 快速开始

### 方式一：直接打开
```bash
# 下载项目后直接用浏览器打开
cd bilingual-reader
open index.html
```

### 方式二：本地服务器（推荐）
```bash
# Python 3
python -m http.server 8080

# Node.js
npx serve .

# PHP
php -S localhost:8080
```

然后访问 `http://localhost:8080`

## 📖 使用方法

### 1. 加载书籍
- 点击「📚 打开书籍」按钮
- 选择EPUB格式文件
- 支持大部分标准EPUB电子书

### 2. 阅读导航
- **目录**：点击📑按钮显示/隐藏目录
- **章节切换**：使用下拉菜单或左右箭头
- **快捷键**：
  - `←/→` 或 `空格`：上一章/下一章
  - `Ctrl/Cmd + B`：切换双语模式
  - `Ctrl/Cmd + T`：翻译当前章节
  - `Ctrl/Cmd + G`：打开术语表
  - `ESC`：关闭弹窗

### 3. AI翻译
- 点击「🤖」按钮翻译当前章节
- 在设置面板选择翻译模型：
  - **Demo模式**：模拟翻译效果（无需API）
  - **本地简单翻译**：基础词汇替换
  - **AI模式**：可接入真实翻译API（需配置）

### 4. 术语查看
- 文中术语自动高亮显示（蓝色下划线）
- 点击术语查看详细解释
- 点击「📖 术语表」查看全部术语
- 支持分类筛选：人物、概念、地点

### 5. 自定义术语

打开浏览器控制台：

```javascript
// 添加新术语
glossaryManager.addTerm('新术语', {
    name: '新术语',
    nameEn: 'New Term',
    type: 'concept',  // character | concept | place
    description: '术语解释内容...',
    tags: ['标签1', '标签2']
});

// 导出术语表
const json = glossaryManager.exportToJSON();
console.log(json);

// 导入术语表
glossaryManager.importFromJSON(jsonString);
```

## 📁 项目结构

```
bilingual-reader/
├── index.html          # 主页面
├── style.css           # 样式表
├── reader.js           # 阅读器核心逻辑
├── glossary.js         # 术语管理系统
├── translator.js       # 翻译模块
├── glossary-data.js    # 术语数据（可选，可分离）
└── README.md           # 本文档
```

## 🔧 扩展开发

### 接入真实AI翻译API

编辑 `translator.js` 中的 `aiTranslate` 方法：

```javascript
async aiTranslate(text, from = 'zh', to = 'en') {
    const response = await fetch('YOUR_API_ENDPOINT', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer YOUR_API_KEY'
        },
        body: JSON.stringify({
            text: text,
            source: from,
            target: to
        })
    });
    
    const data = await response.json();
    return data.translation;
}
```

### 支持的翻译服务
- **OpenAI GPT**：高质量翻译，保留上下文
- **Google Translate API**：快速、经济
- **DeepL API**：欧洲语言翻译质量高
- **自托管模型**：Llama、ChatGLM等本地部署

### 主题定制

在 `style.css` 中添加新主题：

```css
[data-theme="custom"] {
    --bg-primary: #your-color;
    --bg-secondary: #your-color;
    --text-primary: #your-color;
    --accent: #your-color;
}
```

## 📚 技术栈

- **epub.js** - EPUB解析和渲染
- **JSZip** - ZIP文件解压（EPUB本质是ZIP）
- **原生JavaScript** - 无框架依赖
- **CSS Variables** - 主题系统

## 📝 注意事项

1. **文件安全**：所有处理都在浏览器本地完成，不会上传到服务器
2. **大文件处理**：超大EPUB文件可能需要等待较长时间
3. **翻译限制**：Demo模式仅供演示，真实翻译需要配置API
4. **术语识别**：基于精确匹配，可能需要手动补充术语表

## 🔮 未来计划

- [ ] 在线词典集成（划词翻译）
- [ ] 阅读进度同步
- [ ] 批注和高亮功能
- [ ] TTS语音朗读
- [ ] 生词本和复习系统
- [ ] 云同步功能

## 📄 许可

MIT License - 可自由使用、修改和分发

## 🙏 致谢

- [futurepress/epub.js](https://github.com/futurepress/epub.js) - EPUB解析引擎
- [Koodo Reader](https://github.com/troyeguo/koodo-reader) - 阅读器UI参考
- [BiReads](https://www.bireads.com/) - 双语阅读理念

---

**享受阅读！📖✨**