/**
 * 双语阅读器核心逻辑
 * 基于 epub.js 构建
 */

// 全局变量
let book = null;
let rendition = null;
let currentChapter = null;
let isBilingualMode = false;

// DOM元素
const els = {
    fileInput: document.getElementById('file-input'),
    btnUpload: document.getElementById('btn-upload'),
    btnToc: document.getElementById('btn-toc'),
    btnPrev: document.getElementById('btn-prev'),
    btnNext: document.getElementById('btn-next'),
    btnMode: document.getElementById('btn-mode'),
    btnTranslate: document.getElementById('btn-translate'),
    btnRetranslate: document.getElementById('btn-retranslate'),
    btnGlossary: document.getElementById('btn-glossary'),
    btnSettings: document.getElementById('btn-settings'),
    chapterSelect: document.getElementById('chapter-select'),
    bookTitle: document.getElementById('book-title'),
    tocPanel: document.getElementById('toc-panel'),
    tocList: document.getElementById('toc-list'),
    viewer: document.getElementById('viewer'),
    chinesePanel: document.getElementById('chinese-panel'),
    englishPanel: document.getElementById('english-panel'),
    englishContent: document.getElementById('english-content'),
    glossaryPanel: document.getElementById('glossary-panel'),
    settingsPanel: document.getElementById('settings-panel'),
    termPopup: document.getElementById('term-popup')
};

// 初始化
function init() {
    bindEvents();
    loadSettings();
    glossaryManager.renderGlossary('characters');
    
    // 检查是否有保存的书籍
    const savedBook = localStorage.getItem('current-book');
    if (savedBook) {
        // 如果有保存的书籍URL，可以自动加载
        // loadBook(savedBook);
    }
}

// 绑定事件
function bindEvents() {
    // 上传文件
    els.btnUpload.addEventListener('click', () => els.fileInput.click());
    els.fileInput.addEventListener('change', handleFileUpload);

    // 导航按钮
    els.btnToc.addEventListener('click', toggleToc);
    els.btnPrev.addEventListener('click', () => rendition?.prev());
    els.btnNext.addEventListener('click', () => rendition?.next());
    els.chapterSelect.addEventListener('change', handleChapterSelect);

    // 功能按钮
    els.btnMode.addEventListener('click', toggleBilingualMode);
    els.btnTranslate.addEventListener('click', translateCurrentChapter);
    els.btnRetranslate.addEventListener('click', translateCurrentChapter);
    els.btnGlossary.addEventListener('click', toggleGlossary);
    els.btnSettings.addEventListener('click', toggleSettings);

    // 设置面板
    document.getElementById('font-size')?.addEventListener('input', handleFontSizeChange);
    document.getElementById('line-height')?.addEventListener('input', handleLineHeightChange);
    document.getElementById('theme-select')?.addEventListener('change', handleThemeChange);
    document.getElementById('translation-model')?.addEventListener('change', handleModelChange);

    // 术语表标签切换
    document.querySelectorAll('.glossary-tabs .tab-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.glossary-tabs .tab-btn').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            glossaryManager.renderGlossary(e.target.dataset.tab);
        });
    });

    // 键盘快捷键
    document.addEventListener('keydown', handleKeyboard);

    // 点击外部关闭弹窗
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.term-popup') && !e.target.closest('.term-highlight')) {
            closePopup();
        }
    });
}

// 处理文件上传
function handleFileUpload(e) {
    const file = e.target.files[0];
    if (!file) return;

    if (!file.name.endsWith('.epub')) {
        alert('请选择EPUB格式的文件');
        return;
    }

    updateLoading(true, '正在解析书籍...');

    const reader = new FileReader();
    reader.onload = (event) => {
        const arrayBuffer = event.target.result;
        loadBook(arrayBuffer);
    };
    reader.readAsArrayBuffer(file);
}

// 加载书籍
function loadBook(data) {
    try {
        // 如果已有书籍，先销毁
        if (book) {
            book.destroy();
        }

        // 创建新书
        book = ePub(data);

        book.loaded.metadata.then(metadata => {
            els.bookTitle.textContent = metadata.title || '未知书名';
            document.title = `${metadata.title || '未知书名'} - AI双语阅读器`;
        });

        book.loaded.navigation.then(navigation => {
            renderToc(navigation.toc);
            populateChapterSelect(navigation.toc);
        });

        // 创建渲染
        rendition = book.renderTo(els.viewer, {
            width: '100%',
            height: '100%',
            spread: 'none',
            flow: 'scrolled-doc'
        });

        // 显示第一章
        rendition.display();

        // 监听章节变化
        rendition.on('relocated', (location) => {
            currentChapter = location.start.href;
            updateTocHighlight(location.start.href);
            updateChapterSelect(location.start.href);
            
            // 章节变化时，清空英文面板
            els.englishContent.innerHTML = `
                <div class="placeholder">
                    <p>🤖 点击右上角翻译按钮生成英文版本</p>
                    <p>Click translate button to generate English version</p>
                </div>
            `;
        });

        // 内容加载后注入术语高亮
        rendition.on('rendered', (section) => {
            highlightTerms(section.document);
        });

        updateLoading(false);

    } catch (error) {
        console.error('加载书籍失败:', error);
        alert('加载书籍失败，请检查文件格式');
        updateLoading(false);
    }
}

// 渲染目录
function renderToc(toc, level = 0) {
    if (!toc || toc.length === 0) return '';

    let html = level === 0 ? '' : '<ul>';
    
    toc.forEach(item => {
        const indent = level * 20;
        html += `
            <li class="toc-item" style="padding-left: ${indent}px" 
                data-href="${item.href}" 
                onclick="navigateToChapter('${item.href}')">
                ${item.label}
            </li>
        `;
        if (item.subitems) {
            html += renderToc(item.subitems, level + 1);
        }
    });

    html += level === 0 ? '' : '</ul>';
    
    if (level === 0) {
        els.tocList.innerHTML = html;
    }
    return html;
}

// 填充章节选择器
function populateChapterSelect(toc) {
    els.chapterSelect.innerHTML = '';
    
    function addOptions(items, prefix = '') {
        items.forEach(item => {
            const option = document.createElement('option');
            option.value = item.href;
            option.textContent = prefix + item.label;
            els.chapterSelect.appendChild(option);
            
            if (item.subitems) {
                addOptions(item.subitems, prefix + '  ');
            }
        });
    }
    
    addOptions(toc);
}

// 更新目录高亮
function updateTocHighlight(href) {
    document.querySelectorAll('.toc-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.href === href) {
            item.classList.add('active');
        }
    });
}

// 更新章节选择器
function updateChapterSelect(href) {
    els.chapterSelect.value = href;
}

// 导航到章节
function navigateToChapter(href) {
    if (rendition) {
        rendition.display(href);
    }
}

// 处理章节选择
function handleChapterSelect(e) {
    const href = e.target.value;
    if (href) {
        navigateToChapter(href);
    }
}

// 切换目录显示
function toggleToc() {
    els.tocPanel.classList.toggle('hidden');
}

// 切换双语模式
function toggleBilingualMode() {
    isBilingualMode = !isBilingualMode;
    document.body.classList.toggle('bilingual-mode', isBilingualMode);
    els.englishPanel.classList.toggle('hidden', !isBilingualMode);
    els.btnMode.title = isBilingualMode ? '切换单语模式' : '切换双语模式';
    
    // 保存设置
    localStorage.setItem('bilingual-mode', isBilingualMode);
}

// 翻译当前章节
async function translateCurrentChapter() {
    if (!rendition) {
        alert('请先加载书籍');
        return;
    }

    // 显示英文面板
    els.englishPanel.classList.remove('hidden');
    document.body.classList.add('bilingual-mode');
    isBilingualMode = true;

    // 获取当前章节内容
    const contents = rendition.getContents();
    if (!contents || contents.length === 0) return;

    const doc = contents[0].document;
    const text = doc.body.innerText || doc.body.textContent;

    updateLoading(true, '正在翻译...');

    try {
        // 翻译
        const translatedParagraphs = await translator.translateChapter(text);
        
        // 渲染结果
        translator.renderTranslation(translatedParagraphs);
        
        updateLoading(false);
    } catch (error) {
        console.error('翻译失败:', error);
        alert('翻译失败，请重试');
        updateLoading(false);
    }
}

// 术语高亮
function highlightTerms(doc) {
    if (!doc) return;

    // 获取所有术语
    const allTerms = [];
    for (const [type, terms] of Object.entries(glossaryManager.data)) {
        for (const name of Object.keys(terms)) {
            allTerms.push(name);
        }
    }

    // 遍历文本节点并高亮
    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT, null, false);
    const textNodes = [];
    
    while (walker.nextNode()) {
        textNodes.push(walker.currentNode);
    }

    textNodes.forEach(textNode => {
        let text = textNode.textContent;
        let hasMatch = false;

        allTerms.forEach(term => {
            if (text.includes(term)) {
                hasMatch = true;
                text = text.replace(new RegExp(term, 'g'), `
                    <span class="term-highlight" data-term="${term}">${term}</span>
                `);
            }
        });

        if (hasMatch) {
            const wrapper = doc.createElement('span');
            wrapper.innerHTML = text;
            textNode.parentNode.replaceChild(wrapper, textNode);
        }
    });

    // 绑定术语点击事件
    doc.querySelectorAll('.term-highlight').forEach(el => {
        el.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            showTermDetail(el.dataset.term);
        });
    });
}

// 显示术语详情
function showTermDetail(termName) {
    const term = glossaryManager.getTerm(termName);
    if (!term) return;

    document.getElementById('term-name').textContent = term.name;
    document.getElementById('term-type').textContent = getTypeLabel(term.type);
    document.getElementById('term-desc').textContent = term.description;
    document.getElementById('term-en').textContent = term.nameEn;

    els.termPopup.classList.remove('hidden');
}

// 关闭弹窗
function closePopup() {
    els.termPopup.classList.add('hidden');
}

// 获取类型标签
function getTypeLabel(type) {
    const labels = {
        character: '人物 Character',
        concept: '概念 Concept',
        place: '地点 Place'
    };
    return labels[type] || type;
}

// 切换术语表面板
function toggleGlossary() {
    els.glossaryPanel.classList.toggle('hidden');
    els.settingsPanel.classList.add('hidden');
}

// 切换设置面板
function toggleSettings() {
    els.settingsPanel.classList.toggle('hidden');
    els.glossaryPanel.classList.add('hidden');
}

// 设置相关
function handleFontSizeChange(e) {
    const size = e.target.value;
    document.getElementById('font-size-value').textContent = size + 'px';
    document.documentElement.style.setProperty('--font-size', size + 'px');
    
    if (rendition) {
        rendition.themes.fontSize(size + 'px');
    }
    
    localStorage.setItem('font-size', size);
}

function handleLineHeightChange(e) {
    const height = e.target.value;
    document.getElementById('line-height-value').textContent = height;
    document.documentElement.style.setProperty('--line-height', height);
    localStorage.setItem('line-height', height);
}

function handleThemeChange(e) {
    const theme = e.target.value;
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
}

function handleModelChange(e) {
    translator.setModel(e.target.value);
}

function loadSettings() {
    // 字体大小
    const fontSize = localStorage.getItem('font-size') || '16';
    document.getElementById('font-size').value = fontSize;
    document.getElementById('font-size-value').textContent = fontSize + 'px';
    
    // 行高
    const lineHeight = localStorage.getItem('line-height') || '1.6';
    document.getElementById('line-height').value = lineHeight;
    document.getElementById('line-height-value').textContent = lineHeight;
    
    // 主题
    const theme = localStorage.getItem('theme') || 'light';
    document.getElementById('theme-select').value = theme;
    document.documentElement.setAttribute('data-theme', theme);
    
    // 双语模式
    const bilingual = localStorage.getItem('bilingual-mode') === 'true';
    if (bilingual) {
        toggleBilingualMode();
    }
    
    // 翻译模型
    const model = localStorage.getItem('translation-model') || 'demo';
    document.getElementById('translation-model').value = model;
}

// 键盘快捷键
function handleKeyboard(e) {
    // 忽略输入框
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

    switch (e.key) {
        case 'ArrowLeft':
            rendition?.prev();
            break;
        case 'ArrowRight':
        case ' ':
            rendition?.next();
            break;
        case 'b':
            if (e.ctrlKey || e.metaKey) {
                e.preventDefault();
                toggleBilingualMode();
            }
            break;
        case 't':
            if (e.ctrlKey || e.metaKey) {
                e.preventDefault();
                translateCurrentChapter();
            }
            break;
        case 'g':
            if (e.ctrlKey || e.metaKey) {
                e.preventDefault();
                toggleGlossary();
            }
            break;
        case 'Escape':
            closePopup();
            els.glossaryPanel.classList.add('hidden');
            els.settingsPanel.classList.add('hidden');
            break;
    }
}

// 更新加载状态
function updateLoading(show, text = '加载中...') {
    const loading = document.getElementById('loading');
    const loadingText = document.getElementById('loading-text');
    
    if (show) {
        loading.classList.remove('hidden');
        loadingText.textContent = text;
    } else {
        loading.classList.add('hidden');
    }
}

// 启动
window.addEventListener('DOMContentLoaded', init);